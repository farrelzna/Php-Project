<?php
    session_start();
    $total_belanja = 0;
    foreach($_SESSION['pembelajaan'] as $belan => $b){
        $total_belanja += $b['harga'] * $b['jumlah'];
        $bayar = $_SESSION['bayar'] - $total_belanja;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struke</title>
    <style>
         @import url("https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400");

        body,
        html {
            font-family: "Source Sans Pro", sans-serif;
            background: #c82333;
            padding: 0;
            margin: 0;
            color: #dfdeee;
        }

        .container {
            width: 50%;
            margin: 50px auto;
            background-color: #2c3338;
            box-shadow: rgba(0, 0, 0, 0.25) 0px 14px 28px, rgba(0, 0, 0, 0.22) 0px 10px 10px;
            padding: 20px;
            border-radius: 8px;
            display: flex;
        }

        h4 {
            font-family: "Source Sans Pro", sans-serif;
            color:#dfdeee;
            margin-top: 20px;
        }

        .section2 {
            display: flex;
        }

        .header {
            display: flex;
        }
        
        .Grup{
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        a {
            color: #a1a4ad;
            text-decoration: none;
        }

        .forgetpass {
            position: relative;
            float: right;
        }

    </style>
</head>
<body>
    <div class="container">
        <div class="section1">
            <h4>Bukti Pembayaran</h4>
            <div class="rand">
                <h4>No.Transaksi #<br><?= uniqid() ?></h4> 
            </div>
            <div class="Date">
                <h4>Date #<br><?= date("l jS \of F Y") ?></h4>
            </div>
        </div>
           
        <div class="section2">
            <table border="1" cellpadding="6" cellspacing="6">
                <tr>
                    <th>Barang</th>
                    <th>Jumlah</th>
                    <th>Harga</th>
                </tr>
                <?php 
                    $i = 1;
                    $total_belanja = 0;
                    $item_exists = false;
                    foreach ($_SESSION['pembelajaan'] as $belan => $b) :
                        $total_belanja += $b['harga'] * $b['jumlah'];
                ?>
                <tr>
                    <td><?= $b['barang'] ?></td>
                    <td><?= $b['jumlah']?></td>
                    <td><?= $b['harga']?></td>
                </tr>
                    <br>
                    <?php endforeach;?>
                </div>
            </table>
        </div>
            
        <div class="section3">    
            <div class="Grup">
                <p>Total</p>
                    <div class="uang">
                    <p>Rp. <?= number_format($total_belanja, 0, ',', '.') ?></p>
                    </div>
            </div>
            <div class="Grup">
                <p>Uang Yang Dibayar</p>
                    <div class="uang">
                    <p>Rp. <?= $_SESSION['bayar'] ?></p>
                    </div>
            </div>
            <div class="Grup">
                <p>Kembalian</p>
                    <div class="uang">
                        <p>Rp. <?= $bayar?></p>
                    </div>
            </div>
            <div class="Grup">
                <p>Terima Kasih Sudah Mengunjungi Di Toko Kami</p>
            </div>
            <a class="forgetpass" href="index.php" onclick="return confirm('Apakah kamu ingin kembali ke halaman utama?')" >Halaman Utama</a>
        </div>
    </div>
</body>
</html>