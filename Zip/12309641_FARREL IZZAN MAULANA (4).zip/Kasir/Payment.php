<?php
session_start();
$total_belanja = 0;
foreach ($_SESSION['pembelajaan'] as $b) {
    $total_belanja += $b['harga'] * $b['jumlah'];
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <title>Pembayaran</title>
    <style>

        @import url("https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400");

        body,
        html {
            font-family: "Source Sans Pro", sans-serif;
            background: #c82444;
            padding: 0;
            margin: 0;
        }

        .container {
            text-align: center;
            background: white;
            border-radius: 9px;
            border-top: 10px solid white;
            border-bottom: 10px solid white;
            width: 400px;
            height: 500px;
        }

        .box h4 {
            font-family: "Source Sans Pro", sans-serif;
            color:#3b4148;
            font-size: 20px;
            margin-top: 20px;
        }

        .box h4 span {
            color: #dfdeee;
            font-weight: lighter;
        }

        .box h5 {
            font-family: "Source Sans Pro", sans-serif;
            font-size: 13px;
            color: #696c72;
            letter-spacing: 1.5px;
            margin-top: -5px;
            margin-bottom: 45px;
        }

        .box input[type="number"] {
            display: block;
            margin: 20px auto;
            background-color: #dbdbdb;
            border: 0;
            border-radius: 5px;
            padding: 14px 10px;
            width: 320px;
            outline: 0;
            color: #a9a9a9;
            -webkit-transition: all 0.2s ease-out;
            -moz-transition: all 0.2s ease-out;
            -ms-transition: all 0.2s ease-out;
            -o-transition: all 0.2s ease-out;
            transition: all 0.2s ease-out;
        }

        ::-webkit-input-placeholder {
            color: #565f79;
        }

        .box input[type="text"]:focus,
        .box input[type="password"]:focus {
            border: 1px solid #79a6fe;
        }
        
        .btn1 {
            border: 0;
            background: #c82444;
            color: #dfdeee;
            border-radius: 7px;
            width: 340px;
            height: 49px;
            font-size: 16px;
            transition: 0.3s;
            cursor: pointer;
            margin-top: 15%;
        }
        
        .btn1:hover {
            background: #a1a4ad;
        }

        a {
            color: #a1a4ad;
            text-decoration: none;
        }

        .forgetpass {
            position: relative;
            float: right;
            right: 28px;
        }

    </style>
</head>
    <body style="display: flex; justify-content:center ; align-items: center;height: 100vh;overflow: hidden;">
        <div class="container">
            <form name="form1" class="box" method="post">
                <h4>Pembayaran</span></h4>
                    <br>
                <h5>Masukan Nominal Uang</h5>
                <input type="number" name="bayar" placeholder="Pastikan uang yang Anda masukan cukup" autocomplete="off" required/>
                    <br>
                <h5>Uang yang harus Anda bayarkan adalah :<br><br><?= "Rp." . number_format($total_belanja, 0, ',', '.'); ?></h5>
                <button type="submit" value="Sign in" class="btn1" name="cash">Bayar</button>
                    <br><br>
                <a class="forgetpass" href="index.php">Halaman awal</a>
            </form>
        </div>
        <div class="" class="position-absolute bottom-0 end-0">
            <?php 
                if (isset($_POST['cash'])) {
                    $uang = $_POST['bayar'];
                    $bayar = $uang - $total_belanja;
                    if ($bayar < 0) {
                        echo 
                        '<div class="alert alert-danger position-absolute" role="alert" style="bottom: 0; right: 0;  margin-right: 10px;">
                            Uang Kamu Kurang syggg~~~~ ah aha hah ah ah
                        </div>';
                    } else {
                        $_SESSION['kembalian'] = $bayar;
                        $_SESSION['bayar'] = $uang;
                        header("Location: Struke.php");
                        exit();
                    }
                }
            ?>
        </div>
    </body>
</html>